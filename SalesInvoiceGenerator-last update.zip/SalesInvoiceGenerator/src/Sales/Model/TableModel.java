/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Sales.Model;

import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;

public class TableModel extends AbstractTableModel {
private  ArrayList<InvoiceHeader> invoices;    
private String[] c={"No.","Date","Customer","Total"};
    
    public TableModel(ArrayList<InvoiceHeader> invoices) {
        this.invoices = invoices;
    }

    @Override
    public int getRowCount() {
       return invoices.size();
    }

    @Override
    public int getColumnCount() {
       
        return c.length;
    }
    
    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
       
       InvoiceHeader invoice= invoices.get(rowIndex);
       switch(columnIndex){
           case 0: return invoice.getNum();
           case 1: return invoice.getDate();
           case 2: return invoice.getCustomer_name();
           case 3: return invoice.getInvoiceTot();
           default: return "";    
       }
       
       
    }
   
    @Override  
    public String getColumnName(int column) {
       return c[column];
    }
    
}
