/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Sales.Controller;

import Sales.Model.InvoiceHeader;
import Sales.Model.InvoiceLine;
import Sales.Model.LinesModel;
import Sales.Model.TableModel;
import Sales.View.InvoiceDialog;
import Sales.View.LineDialog;
import Sales.View.SalesInvoiceFrame;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import javax.swing.JComponent;
import java.util.List;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


/**
 *
 * @author galaxy
 */
public class Ctrl implements ActionListener, ListSelectionListener {

    private SalesInvoiceFrame frame_out;
    private InvoiceDialog invoice_dialog;
    private LineDialog lineDialog;
    private LinesModel line;
    public Ctrl(SalesInvoiceFrame frame_out) {

        this.frame_out = frame_out;

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String actionCommand = e.getActionCommand();
        System.out.println(actionCommand);
        switch (actionCommand) {

            case "Load File":
                loadfile();
                break;
            case "Save File":
                savefile();
                break;

            case "Creat New Invoice":
                CreateNewInvoice();
                break;
            case "Delete Invoice":
                deleteInvoice();
                break;
            case "Create new Item":
                createNewItem();
                break;
            case "Delete Item":
                deleteItem();
                break;
             
            case "createLineOK":
                createLineOK();
                break;
            case "createLineCancel":
                createLineCancel();
                break;
            case "createInvoiceCancel":
                    createInvoiceCancel();
                    break;
            case "createInvoiceOK":
                createInvoiceOK();
                break;
            
          
            
        }

    }

    @Override
    public void valueChanged(ListSelectionEvent e) {
        int Index_Number = frame_out.getInvoicetable().getSelectedRow();
        if(Index_Number != -1){
        System.out.println("No.Row Selected:" + Index_Number);
        InvoiceHeader currentInvoice = frame_out.getInvoices().get(Index_Number);
        frame_out.getInvoiceNumLabel().setText("" + currentInvoice.getNum());
        frame_out.getInvoiceDateLabel().setText(currentInvoice.getDate());
        frame_out.getCustomerNameLabel().setText(currentInvoice.getCustomer_name());
        frame_out.getInvoiceTotal().setText("" + currentInvoice.getInvoiceTot());
        LinesModel linesmodeltable = new LinesModel(currentInvoice.getLines());
        frame_out.getLinetable().setModel(linesmodeltable);
        linesmodeltable.fireTableDataChanged();
        }
    }

    private void loadfile() {
        JFileChooser f = new JFileChooser();
        try {
            int x = f.showOpenDialog(frame_out);
            if (x == JFileChooser.APPROVE_OPTION) {
                File invoice_headerfile = f.getSelectedFile();
                Path header_path = Paths.get(invoice_headerfile.getAbsolutePath());
                List<String> headerLines = Files.readAllLines(header_path);
                ArrayList<InvoiceHeader> invoicesArray = new ArrayList<>();
                
                for (String headerLine : headerLines) {
                try{
                    String[] h_parts = headerLine.split(",");
                    int invoice_num = Integer.parseInt(h_parts[0]);
                    String invoice_date = h_parts[1];
                    String customer_name = h_parts[2];
                    InvoiceHeader invoice = new InvoiceHeader(invoice_num, invoice_date, customer_name);
                    invoicesArray.add(invoice);
                } catch(Exception e){
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(frame_out,"Error Line Format","Error",JOptionPane.ERROR_MESSAGE);
                }
                }
                x = f.showOpenDialog(frame_out);
                if (x == JFileChooser.APPROVE_OPTION) {
                    File invoice_linefile = f.getSelectedFile();
                    Path line_path = Paths.get(invoice_linefile.getAbsolutePath());
                    List<String> lineOfLines = Files.readAllLines(line_path);
                    for (String lineLine : lineOfLines) {
                        try{
                        String[] l_parts = lineLine.split(",");
                        int invoice_num = Integer.parseInt(l_parts[0]);
                        String itemName = l_parts[1];
                        double itemPrice = Double.parseDouble(l_parts[2]);
                        int count = Integer.parseInt(l_parts[3]);
                        InvoiceHeader n_inv = null;

                        for (InvoiceHeader invoice : invoicesArray) {
                            if (invoice.getNum() == invoice_num) {
                                n_inv = invoice;
                                break;
                            }
                        }
                        InvoiceLine l = new InvoiceLine(itemName, itemPrice, count, n_inv);
                        n_inv.getLines().add(l);
                        } catch(Exception e){
                              e.printStackTrace();
                              JOptionPane.showMessageDialog(frame_out,"Error Line Format","Error",JOptionPane.ERROR_MESSAGE);
                              
                        }
                    }
                }
                frame_out.setInvoices(invoicesArray);
                TableModel table_model = new TableModel(invoicesArray);
                frame_out.setInvoicestabelemodel(table_model);
                frame_out.getInvoicetable().setModel(table_model);
                frame_out.getInvoicestablemodel().fireTableDataChanged();
                }
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame_out, "The Type Of File Is Wrong","Error", JOptionPane.ERROR_MESSAGE); 
        }
    }

    private void savefile() {
        ArrayList<InvoiceHeader> invoices=frame_out.getInvoices();
        String H="";
        String L="";
        for(InvoiceHeader invoice: invoices ){
              String invCSV= invoice.getS_Fil();
              H += invCSV;
              H+="\n";
              for(InvoiceLine line:invoice.getLines()){
              String lineCSV=line.getS_Fil();
              L+=lineCSV;
              L+="\n";
              }
              
          }
        try{
        JFileChooser fc=new JFileChooser();
        int result=fc.showSaveDialog(frame_out);
        if(result== JFileChooser.APPROVE_OPTION)
        {
           File Headerfile=fc.getSelectedFile();
           FileWriter hf=new FileWriter(Headerfile);
           hf.write(H);
           hf.flush();
           hf.close();
           result=fc.showSaveDialog(frame_out);
           if(result== JFileChooser.APPROVE_OPTION)
           {
             File Linefile=fc.getSelectedFile();
               FileWriter lf=new FileWriter(Linefile);
           lf.write(L);
           lf.flush();
           lf.close();
           }
           
        }
        }catch (Exception exception){
        }
    }

    private void CreateNewInvoice() {
        invoice_dialog = new InvoiceDialog(frame_out);
        invoice_dialog.setVisible(true);

    }

    private void deleteInvoice() {
        int row = frame_out.getInvoicetable().getSelectedRow();
        if (row != -1) {
            frame_out.getInvoices().remove(row);
            frame_out.getInvoicestablemodel().fireTableDataChanged();
        

        }

    }

    private void createNewItem() {
        LineDialog lineDialog = new LineDialog(frame_out);
        lineDialog.setVisible(true);

    }

    private void deleteItem() {
        int x = frame_out.getInvoicetable().getSelectedRow();
        int row = frame_out.getLinetable().getSelectedRow();
        if (x != -1 && row != -1) {
            InvoiceHeader invoice = frame_out.getInvoices().get(x);
            invoice.getLines().remove(row);
            LinesModel linestablemodel = new LinesModel(invoice.getLines());
            frame_out.getLinetable().setModel(linestablemodel);
            linestablemodel.fireTableDataChanged();
            frame_out.getInvoicestablemodel().fireTableDataChanged();
            
            

        }

    }

    private void createInvoiceCancel() {
        invoice_dialog.setVisible(false);
        invoice_dialog.dispose();
        invoice_dialog = null;

    }

    private void createInvoiceOK() {
          
        String date = invoice_dialog.getInvDateField().getText();
        String customer = invoice_dialog.getCustNameField().getText();
        int num = frame_out.getNextInvoiceNum();          
            InvoiceHeader invoice = new InvoiceHeader(num, date, customer);
               frame_out.getInvoices().add(invoice);
               frame_out.getInvoicestablemodel().fireTableDataChanged();
               invoice_dialog.setVisible(false);
               invoice_dialog.dispose();
               invoice_dialog=null;
   
           }

       
    private void createLineOK() 
    {
        
        
        String it = lineDialog.getItemNameField().getText();
        String coun_string = lineDialog.getItemCountField().getText();
        String price_string = lineDialog.getItemPriceField().getText();
        int count = Integer.parseInt(coun_string);
        double price = Double.parseDouble(price_string);
        int row_select=frame_out.getInvoicetable().getSelectedRow();
       
        if(row_select != -1)
        {
        InvoiceHeader invoice= frame_out.getInvoices().get(row_select);
        InvoiceLine line=new InvoiceLine(it,price,count,invoice);
        invoice.getLines().add(line);
        
        
        LinesModel linesmodel= (LinesModel) frame_out.getLinetable().getModel();
        linesmodel.fireTableDataChanged();
        frame_out.getInvoicestablemodel().fireTableDataChanged();
        }
        lineDialog.setVisible(false);
        lineDialog.dispose();
        lineDialog = null;
        
    }

    private void createLineCancel() {
        lineDialog.setVisible(false);
        lineDialog.dispose();
        lineDialog = null;
    }

}
